import { Component, OnInit, Input } from '@angular/core';
import { Blog } from '../blogadmin/blogpost';
import { BlogService } from './blog.service';
import { HttpClient, HttpErrorResponse, HttpResponse} from '@angular/common/http';
import { Router } from '@angular/router';

@Component({

  selector: 'app-blogadmin',
  templateUrl: '../blogadmin/blogadmin.component.html'
})
export class BlogadminComponent implements OnInit {
  postedAt : string;
  lastUpdatedAt:string;
  title : string;
  text : string;
  author : string;
  posts :Blog;
  msg : string ="" ;
  constructor(private blogService: BlogService, private _router:Router) { }

  ngOnInit() {
    this.getBlogPost();
  }

  getBlogPost(): any {
    this.blogService.fetch().subscribe (
      // the first argument is a function which runs on success
      result => { console.log(result); return this.posts = result;     
      
      },
      // the second argument is a function which runs on error
      err => console.error(err),
      // the third argument is a function which runs on completion
      () => console.log('done loading blogposts')
    );
  }
  getAPost(postId: string): any {
    this.blogService.fetchOne(postId).subscribe (
      // the first argument is a function which runs on success
      result => { console.log(result); this.posts = result;  
      },
      // the second argument is a function which runs on error
      err => console.error(err),
      // the third argument is a function which runs on completion
      () => console.log('done loading blogposts')
    );
  }

  //delete the element
  deletePost(postId : string){
    this.blogService.deletePost(postId).subscribe(result => {      
      //refresh the table after deleting
      this.getBlogPost();   
      
     
      console.log("deleted");      
    })
    
  }

  //edit the element
  /*editPost(postId: string, body : any){
    body = {"date": this.date.toDateString() + this.date.toLocaleTimeString(), "title": this.title, "text": this.text, "author": this.author};      
    this.blogService.editPost(postId, body).subscribe(this.success.bind(this), this.error.bind(this))
  
  }

  error(err: HttpErrorResponse){
    this.msg = "Some problem with saving data."
  }
  success(response : HttpResponse<Location>){
       
    let postObject: Location = response.body;
    this.msg =`Saved with an id of ${postObject}`
    this.getBlogPost();

  }*/
  
  editPost(postId:any){
    this._router.navigate(['/edit', postId]);
  }
  
}