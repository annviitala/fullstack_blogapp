export interface Blog{
    id : number;
    postedAt : Date;
    lastUpdatedAt:Date;
    title : string;
    text : string;
    author : string;
    comments:[Comment];
}