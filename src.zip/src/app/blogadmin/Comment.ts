export interface Comment {
    id: number;
    postedAt: string;
    text:string;
    commenter:string;
}