import { Injectable } from '@angular/core';
import { Blog } from './blogpost';
import { HttpClient } from '@angular/common/http';

@Injectable()

export class BlogService {
    posts : Blog;
    private url: string = "http://localhost:8080/blogposts/";
    private http: HttpClient
    
    constructor(http: HttpClient){
        this.http = http;
    }
    //send a GET resquest to the APi to get all data object
    /*fetchComment() {
        // return an array of posts objects
        return this.http.get<Blog>(this.url, {observe:'response'});
    }*/
    //send a GET resquest to the APi to get all data object
    fetch() {
        // return an array of posts objects
        return this.http.get<Blog>(this.url);
    }

    //send a GET resquest to the APi to get adata object
    fetchOne(postId: any) {
        // return an array of posts objects
        return this.http.get<Blog>(this.url + postId);
    }
    
    // send a POST request to the API to create a new data object
    addToServer(body: any) {
        return this.http.post(this.url, body, {observe:'response'});
    }

    // send a DELETE request to the API to delete a data object
     deletePost(postId : string) {        
        return this.http.delete(this.url + postId, { observe: 'response', responseType: 'text' });
    }

    
    // send a PUT request to the API to update a data object
    saveEdit(postId: any, body : any) {
       return this.http.put(this.url + postId, body, {observe : 'response'});

    }
    
                                                                        ujjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjj
  }
  