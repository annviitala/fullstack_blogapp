import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import{ ActivatedRoute, Params } from '@angular/router';
import { Blog } from '../blogadmin/blogpost';
import { BlogService} from '../blogadmin/blog.service';
import { HttpClient, HttpErrorResponse, HttpResponse} from '@angular/common/http';

@Component({
  selector: 'app-edit',
  template: `<div class="col-sm-12">
  <h2>Edit A Post</h2>
  <form *ngIf="posts" class = "form-horizontal">
    <div class = "form-group">
      <label class = "control-label col-sm-2" for="title">{{posts.id}}</label>
    </div>
    <div class = "form-group">
      <label class = "control-label col-sm-2" for="title">Title:</label>
      <div class ="col-sm-10">
        <input type="text" placeholder="title" name="title" [(ngModel)]="posts.title"/>
      </div>
    </div>
    <div class = "form-group">
      <label class = "control-label col-sm-2" for="text">Post Text:</label>
      <div class ="col-sm-10">
        <textarea [(ngModel)]="posts.text" name = "text"></textarea>
      </div>
    </div>
    <div class = "form-group">
      <label class = "control-label col-sm-2" for="author">Author:</label>
      <div class ="col-sm-10">
        <input type="text" placeholder="author" name="author" [(ngModel)]="posts.author"/>
      </div>
    </div>
    <div class = "form-group">
      <div class ="col-sm-offset-2 col-sm-10">
        <button class = "btn btn-default" (click)="saveEdit(posts.Id, posts)">Save</button>
        
        </div>
    </div>
  </form>
</div>
`
})
export class EditComponent implements OnInit {
  @Input() posts :Blog;
  @Output() close = new EventEmitter();
  post:Blog;
  lastUpdatedAt:Date = new Date();
  //date: string = this.writedate.toString();
  title : string;
  text : string;
  author : string;
  msg : string ="" ;
 navigated: boolean=false;
  constructor(private blogService: BlogService, private route: ActivatedRoute) { }

  ngOnInit(): void {
    this.route.params.forEach((params: Params) => {
      if (params['id'] !== undefined) {
        const id = +params['id'];
        this.navigated = true;
        this.blogService.fetchOne(id)
            .subscribe(posts => this.posts = posts);
      } else {
        this.navigated = false;
        this.posts = this.post;
      }
    });
  }
 
  
  
  saveEdit(postId: any, body : any){
    body = {"lastUpdatedAt": this.lastUpdatedAt.toDateString() + this.lastUpdatedAt.toTimeString(), "title": this.posts.title, "text": this.posts.text, "author": this.posts.author};      
    this.blogService.saveEdit(this.posts.id, body).subscribe(this.success.bind(this), this.error.bind(this))
  
  }

  error(err: HttpErrorResponse){
    this.msg = "Some problem with saving data."
  }
  success(response : HttpResponse<Blog>){
       
    let postObject: Blog = response.body;
    this.msg =`Saved with an id of ${this.posts.id}`
    alert(this.msg);
  
  }

 
  
}
