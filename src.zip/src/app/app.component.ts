import { Component, Input } from '@angular/core';
import { Blog } from './blogadmin/blogpost';

@Component({
  selector: 'app-root',
  templateUrl: `./app.component.html`
})
export class AppComponent {
  //title = 'Ann\'s Blog';


}
