import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppComponent } from './app.component';
import { BlogadminComponent } from './blogadmin/blogadmin.component';
import { BlogService } from './blogadmin/blog.service';
import { HttpClientModule} from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { AddComponent } from './add/add.component';
import { Routes, RouterModule } from '@angular/router';
import { BlogviewComponent } from './blogview/blogview.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { EditComponent } from './edit/edit.component';
import { CommentviewComponent } from './commentview/commentview.component';
import { FilterPipe } from './blogview/filter.pipe';

const router: Routes =[
  {path : '', redirectTo: '/blog', pathMatch: 'full'},
  {path : 'blog', component: BlogviewComponent },
  {path : 'admin', component: BlogadminComponent},
  {path : 'edit/:id', component: EditComponent},
  {path : 'makecomment/:id', component: CommentviewComponent},
];

@NgModule({
  declarations: [
    AppComponent,
    BlogadminComponent,
    AddComponent,
    BlogviewComponent,
    HeaderComponent,
    FooterComponent, 
    EditComponent,
    CommentviewComponent, 
    FilterPipe
  ],
  imports: [
    BrowserModule, HttpClientModule, FormsModule, RouterModule.forRoot(router, {enableTracing:true})
  ],
  providers: [BlogService],
  bootstrap: [AppComponent]
})
export class AppModule { }