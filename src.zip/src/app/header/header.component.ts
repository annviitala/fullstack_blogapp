import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { BlogService } from '../blogadmin/blog.service';
import { Blog } from '../blogadmin/blogpost';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  posts : Blog;
  @Output() sendToAdminPage = new EventEmitter<Object>();
  constructor(private blogService :  BlogService) { }

  ngOnInit() {
    this.getBlogPost();
  }

  getBlogPost(): any {
    this.blogService.fetch().subscribe (
      // the first argument is a function which runs on success
      result => { console.log(result); 
        this.posts = result; 
        this.sendToAdminPage.emit(this.posts);
      
      },
      // the second argument is a function which runs on error
      err => console.error(err),
      // the third argument is a function which runs on completion
      () => console.log('done loading blogposts')
    );
  }

}
