import { Component, OnInit, Input } from '@angular/core';
import{ ActivatedRoute, Params } from '@angular/router';
import { Blog } from '../blogadmin/blogpost';
import { BlogService} from '../blogadmin/blog.service';


@Component({
  selector: 'app-commentview',
  templateUrl: './commentview.component.html',
  styleUrls: ['./commentview.component.css']
})
export class CommentviewComponent implements OnInit {

  @Input() posts :Blog;
  post:Blog;
  comments:Comment[]=[];
  msg : string ="" ;
  navigated: boolean=false;
  
  constructor(private blogService: BlogService, private route: ActivatedRoute) { }

  ngOnInit(): void {
    this.route.params.forEach((params: Params) => {
      if (params['id'] !== undefined) {
        const id = +params['id'];
        this.navigated = true;
        this.blogService.fetchOne(id)
            .subscribe(posts => {
              this.posts = posts
              this.comments = posts.comments
            });
      } else {
        this.navigated = false;
        this.posts = this.post;
      }
    });
  }
 
  /*getPostComments(): any {
    this.blogService.fetchComment().subscribe (
      // the first argument is a function which runs on success
      response => { console.log(response);
        this.comments = response.body.comments;     
      
      },
      // the second argument is a function which runs on error
      err => console.error(err),
      // the third argument is a function which runs on completion
      () => console.log('done loading blogposts')
    );
  }*/
}
