import { Component, OnInit } from '@angular/core';
import { Blog } from '../blogadmin/blogpost';
import { BlogService } from '../blogadmin/blog.service';
import { BlogadminComponent } from '../blogadmin/blogadmin.component';
import { HttpClient, HttpErrorResponse, HttpResponse} from '@angular/common/http';

@Component({
  selector: 'app-add',
  template: `<div class="col-sm-4">
                <h2>Add A Post</h2>
                <form class = "form-horizontal">
                  <div class = "form-group">
                    <label class = "control-label col-sm-2" for="title">Title:</label>
                    <div class ="col-sm-10">
                      <input type="text" placeholder="title" name="title" [(ngModel)]="title"/>
                    </div>
                  </div>
                  <div class = "form-group">
                    <label class = "control-label col-sm-2" for="text">Post Text:</label>
                    <div class ="col-sm-10">
                      <textarea [(ngModel)]="text" name = "text"></textarea>
                    </div>
                  </div>
                  <div class = "form-group">
                    <label class = "control-label col-sm-2" for="author">Author:</label>
                    <div class ="col-sm-10">
                      <input type="text" placeholder="author" name="author" [(ngModel)]="author"/>
                    </div>
                  </div>
                  <div class = "form-group">
                    <div class ="col-sm-offset-2 col-sm-10">
                      <button class = "btn btn-default" (click)="addToServer(posts)">Add</button>
                    </div>
                  </div>
                </form>
            </div>
            `
})
export class AddComponent  {
  postedAt : Date = new Date();
  lastUpdatedAt:Date = new Date();;
  title : string;
  text : string;
  author : string;
  posts :Blog;
  msg : string ="" ;
  constructor(private blogService : BlogService, private blogadminComp:BlogadminComponent) { }

  addToServer(body : any){
    body = {"postedAt": this.postedAt.toDateString()+ this.postedAt.toTimeString(), "lastUpdatedAt": this.lastUpdatedAt.toDateString() + this.lastUpdatedAt.toTimeString(),"title": this.title, "text": this.text, "author": this.author};      
    this.blogService.addToServer(body).subscribe(this.success.bind(this), this.error.bind(this))
  
  }

  error(err: HttpErrorResponse){
    this.msg = "Some problem with saving data."
  }
  success(response : HttpResponse<Blog>){
       
    let postObject: Blog = response.body;
    this.msg =`Saved with an id of ${postObject}`
    // refresh table to show added element 
    this.getPost();
  }
  // declare getPost method from BlogadminComponent
  getPost() : any{
    //declare the method that displays the table  
    return this.blogadminComp.getBlogPost();
  }

}