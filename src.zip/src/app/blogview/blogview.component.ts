import { Component, OnInit } from '@angular/core';
import { BlogadminComponent } from '../blogadmin/blogadmin.component';
import { Blog } from '../blogadmin/blogpost';
import { BlogService} from '../blogadmin/blog.service';
import { Pipe, PipeTransform } from '@angular/core';
import { FilterPipe } from '../blogview/filter.pipe';

@Component({
  selector: 'app-blogview',
  templateUrl: `./blogview.component.html`,
  styleUrls: ['./blogview.component.css']
})
export class BlogviewComponent implements OnInit {
  posts : Blog;
  
  constructor(private blogService: BlogService) {}

  ngOnInit() {
    this.getBlogPost();
  }

  getBlogPost(){
    this.blogService.fetch().subscribe (
      // the first argument is a function which runs on success
      result => { this.posts = result;   
      console.log(result);
      },
      // the second argument is a function which runs on error
      err => console.error(err),
      // the third argument is a function which runs on completion
      () => console.log('done loading blogposts')
    );
  }
}
