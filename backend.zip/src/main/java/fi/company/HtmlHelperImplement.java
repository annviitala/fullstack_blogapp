package fi.company;

import org.springframework.stereotype.Service;

@Service
public class HtmlHelperImplement implements HtmlHelper{
    public String createH1(String title) {
        String str = "<h1>" + title + "</h1>";
        return str;
    }
}