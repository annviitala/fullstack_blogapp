package fi.company;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class Application {
    public static void main(String[] args) {
        SpringApplication.run(Application.class, args);

    }

    @Bean
    public CommandLineRunner getBean() {
        class CommandLineTest implements CommandLineRunner {
            public void run(String... strings) throws Exception {
                //System.out.println("Hello World!");

                System.out.println("Hello World!");
            }
        }
        //return (CommandLineRunner) args -> System.out.println("Hello World!");
        return new CommandLineTest();
    }
}