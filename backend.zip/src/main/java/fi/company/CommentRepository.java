package fi.company;

import org.springframework.data.repository.CrudRepository;

public interface CommentRepository  extends CrudRepository <Comment, Long>{
}
