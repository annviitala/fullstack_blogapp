package fi.company;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import javax.annotation.PostConstruct;
import java.util.Date;

// mvn compile
// mvn spring-boot:run

@RestController
public class MyRestController {
    @Autowired
    BlogRepository database;

    @Autowired
    CommentRepository commentdb;

    @PostConstruct
    public void init() {
        //called when spring has created the bean
        //initDatabase();
    }

    //----------------To save a blogpost------------------
    @RequestMapping(value = "/blogposts",  method= RequestMethod.POST)
    public Blog saveBlogPost(@RequestBody Blog b) {
        //database.saveEntity(c);

        database.save(b);
        return b;
    }

    //----------------To get all blogpost------------------
    @RequestMapping(value = "/blogposts",  method=RequestMethod.GET)
    public Iterable<Blog> fetchAllBlogPosts() {
        //System.out.println("Get customers");
        return database.findAll();
    }

    //----------------To get a blogpost------------------
    @RequestMapping(value = "/blogposts/{id}",  method=RequestMethod.GET)
    public Blog fetchBlogPost(@PathVariable long id) {
        // System.out.println("Get id");
        return database.findOne(id);
    }

    //----------------To delete a blogpost------------------
    @RequestMapping(value = "/blogposts/{id}", method = RequestMethod.DELETE)
    public void deleteAPost(@PathVariable long id){

        database.delete(id);
    }

    //----------------To update a blogpost------------------
    @RequestMapping(value = "/blogposts/{id}", method = RequestMethod.PUT)
    public Blog updateAPost(@PathVariable long id, @RequestBody Blog b){
        Blog update = database.findOne(id);
        update.setPostedAt(b.getPostedAt());
        update.setlastUpdatedAt(b.getlastUpdatedAt());
        update.setTitle(b.getTitle());
        update.setText(b.getText());
        update.setAuthor(b.getAuthor());
        return database.save(update);
    }

    //----------------To save a comment------------------
    @RequestMapping(value = "/comments",  method= RequestMethod.POST)
    public Comment saveComment(@RequestBody Comment c) {
        //database.saveEntity(c);

        commentdb.save(c);
        return c;
    }

    //----------------To get all comment------------------
    @RequestMapping(value = "/comments",  method=RequestMethod.GET)
    public Iterable<Comment> fetchAllComments() {
        //System.out.println("Get customers");
        return commentdb.findAll();
    }

    //----------------To get a comment------------------
    @RequestMapping(value = "/comments/{id}",  method=RequestMethod.GET)
    public Comment fetchComment(@PathVariable long id) {
        // System.out.println("Get id");
        return commentdb.findOne(id);
    }

    //----------------To delete a blogpost------------------
    @RequestMapping(value = "/comments/{id}", method = RequestMethod.DELETE)
    public void deleteAComment(@PathVariable long id){

        commentdb.delete(id);
    }

   /* public void initDatabase(){
        Blog b1 = new Blog();

        Date date = new Date();
        b1.setDate(date.toString());
        b1.setTitle("Mosse posseraa");
        b1.setText("Isäntä harrastaa valokuvausta. " +
                " Tämä kuva on yksi niistä monista ihanista kuvista. " +
                " Olen isännän lempi valokuvamalli. " +
                " Hän on ottanut paljon kuvia ja videota minusta.");
        b1.setAuthor("Ann");

        Comment comment1 = new Comment();
        comment1.setDate(date.toString());
        comment1.setText("Hyvää Mosse!");
        comment1.setCommenter("Matti");

        b1.addComment(comment1);
        commentdb.save(comment1);
        database.save(b1);

    }*/
}
