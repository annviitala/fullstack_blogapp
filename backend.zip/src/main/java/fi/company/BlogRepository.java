package fi.company;

/*public interface BlogRepository  extends MyRepository<Customer, Long>{
}*/

//Restful interface uses Spring Data in implementation instead of own created repository

import org.springframework.data.repository.CrudRepository;

public interface BlogRepository extends CrudRepository<Blog, Long> {


}