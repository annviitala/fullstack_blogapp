package fi.company;
import com.fasterxml.jackson.annotation.JsonIgnore;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.util.*;

@Entity
@Table(name="posts")
public class Blog{

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    private String postedAt;
    @NotNull
    private String lastUpdatedAt;
    @NotNull
    private String title;
    @NotNull
    private String text;
    @NotNull
    private String author;

    @OneToMany(cascade = CascadeType.ALL,
        fetch = FetchType.LAZY,
        mappedBy = "post", orphanRemoval = true)
    private Set<Comment> comments = new HashSet<>();

    public Blog() {
    }

    public Blog(long id, String postedAt, String lastUpdatedAt, String title, String text, String author) {
        this.id = id;
        this.postedAt = postedAt;
        this.lastUpdatedAt = lastUpdatedAt;
        this.title = title;
        this.text = text;
        this.author = author;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getPostedAt() {
        return postedAt;
    }

    public void setPostedAt(String postedAt) {
        this.postedAt = postedAt;
    }

    public String getlastUpdatedAt() {
        return lastUpdatedAt;
    }

    public void setlastUpdatedAt(String lastUpdatedAt) {
        this.lastUpdatedAt = lastUpdatedAt;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public Set<Comment> getComments() {
        return comments;
    }

    public void setComments(Set<Comment> comments) {
        this.comments = comments;
    }

    public void addComment(Comment comment){
        comments.add(comment);
        comment.setPost(this);
    }

    public void removeComment(Comment comment){
        comment.setPost(null);
        this.comments.remove(comment);
    }

    @Override
    public String toString() {
        return "Blog{" +
                "id=" + id +
                ", postedAt='" + postedAt + '\'' +
                ", lastUpdatedAt='" + lastUpdatedAt + '\'' +
                ", title='" + title + '\'' +
                ", text='" + text + '\'' +
                ", author='" + author + '\'' +
                '}';
    }
}
