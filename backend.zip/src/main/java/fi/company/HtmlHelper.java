package fi.company;

public interface HtmlHelper {
    public String createH1(String title);
}
