package fi.company;

public interface MyRepository <T, ID>{
    public T saveEntity(T entity);
    public T save(T entity);
}
