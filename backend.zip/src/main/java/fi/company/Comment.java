package fi.company;

import com.fasterxml.jackson.annotation.JsonIgnore;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.util.Date;

@Entity
@Table(name="comments")
public class Comment {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;
    @NotNull
    private String date;
    @NotNull
    private String text;
    @NotNull
    private String commenter;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "post_id", nullable = false)
    private Blog post;

    public Comment(){}

    public Comment(long id, String date, String text, String commenter) {
        this.id = id;
        this.date = date;
        this.text = text;
        this.commenter = commenter;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public String getCommenter() {
        return commenter;
    }

    public void setCommenter(String commenter) {
        this.commenter = commenter;
    }
    @JsonIgnore
    public Blog getPost() {
        return post;
    }

    public void setPost(Blog post) {
        this.post = post;
    }
}